package Entidades;

public class Pessoa {
    public Pessoa(int id, String nome, String endereco, String cidade, String telefone) {
        Id = id;
        Nome = nome;
        Endereco = endereco;
        Cidade = cidade;
        Telefone = telefone;
    }
    
    public int Id;
    public String Nome;    
    public String Endereco;
    public String Cidade;
    public String Telefone;
}
