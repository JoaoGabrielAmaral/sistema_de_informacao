package Pack1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet1 extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Servlet1</title>");            
            out.println("</head>");
            out.println("<body>");
            
            String linhas = request.getParameter("linhas");
            if (linhas != null && linhas != "") {
                try {
                    int quantidade = Integer.parseInt(linhas);
                    if (quantidade == 0)
                        out.println("<p>Informe o parâmetro \"linhas\"</p>");
                    else
                        for (int i = 1; i <= quantidade; i++)
                            out.println("<p>Linha: " + i + "</p>");
                } catch(Exception ex) {
                    out.println("<p>Parâmetros \"linhas\" deve conter apenas números</p>");
                }
            } else
                out.println("<p>Informe o parâmetro \"linhas\"</p>");
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
