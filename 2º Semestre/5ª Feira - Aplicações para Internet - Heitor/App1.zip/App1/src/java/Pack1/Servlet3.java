package Pack1;

import Entidades.Pessoa;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet3 extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher("/crud.jsp");
        
        int linhas = 0;
        String message = "";
        try {
            String param = request.getParameter("linhas");
            if (param == null || param == "")
                message = "Favor informar o parâmetro \"linhas\"";
            else {
                linhas = Integer.parseInt(param);
                if (linhas == 0)
                    message = "Parâmetro \"linhas\" deve ser maior que 0";
            }
        } catch (Exception e) {
            message = "Favor informar o parâmetro \"linhas\" somente com números";
        }
        request.setAttribute("message", message);
                
        List<Pessoa> pessoas = new ArrayList<>();
        for (int i = 1; i <= linhas; i++)
            pessoas.add(new Pessoa(i, "Nome " + i, "Endereço " + i, "Cidade " + i, "Telefone " + i));
        
        request.setAttribute("pessoas", pessoas);
        view.forward(request, response);   
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
